import { Component } from '@angular/core';

@Component({
  selector: 'myapp',
  template: '<h1>Welcome....!!!</h1>'
})
export class AppComponent {}
